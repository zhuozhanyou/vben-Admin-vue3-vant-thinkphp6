// base rc-switch 1.9.0
import Switch from './Switch';

export default Switch;
