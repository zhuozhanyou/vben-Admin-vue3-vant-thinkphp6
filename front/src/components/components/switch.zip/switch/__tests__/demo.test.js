import demoTest from '../../../tests/shared/demoTest';

demoTest('switch');
